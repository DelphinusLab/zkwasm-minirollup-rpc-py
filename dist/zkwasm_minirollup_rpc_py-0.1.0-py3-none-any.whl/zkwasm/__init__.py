#!/usr/bin/env python
# -*- coding: UTF-8 -*-
from .rpc import ZKWasmAppRpc, AsyncZKWasmAppRpc
